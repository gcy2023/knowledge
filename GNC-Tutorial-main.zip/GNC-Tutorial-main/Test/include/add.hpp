#ifndef ADD_HPP
#define ADD_HPP

int add(int a, int b);


#endif //