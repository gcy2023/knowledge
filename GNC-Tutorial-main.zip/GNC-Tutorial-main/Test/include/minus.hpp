#ifndef MINUS_HPP
#define MINUS_HPP

int minus(int a, int b);


#endif // MINUS_HPP